 function rowClicked(row) {
      row.classList.toggle('selected');
    }
    window.onload = function() {
      const rows = document.querySelectorAll('table tr:not(:first-child)');
      rows.forEach(row => {
        row.onclick = function() {
          rowClicked(row);
        }
      });
    }